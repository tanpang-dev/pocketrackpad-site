#!/bin/bash
# PockeTrackPadConnect.command
#
# Finderからダブルクリックして実行するためのラッパー。
# 同じフォルダ内のコンパイル済みユニバーサルバイナリ(PockeTrackPadConnect)を
# 相対パスで起動する。Terminal.appが.commandファイルを実行してくれる
# macOS標準の仕組みを利用している。

DIR="$(cd "$(dirname "$0")" && pwd)"
BINARY="$DIR/PockeTrackPadConnect"

if [ ! -f "$BINARY" ]; then
    echo "PockeTrackPadConnect が見つかりません。同じフォルダに置いてください。 / PockeTrackPadConnect not found. Keep it in the same folder as this file."
    echo "Press Enter to close / Enterキーで閉じる"
    read -r
    exit 1
fi

chmod +x "$BINARY" 2>/dev/null

"$BINARY"
exit $?
